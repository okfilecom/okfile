# @okfilecom/okfile

`@okfilecom/okfile` is an npm launcher for the OkFile CLI.

It reuses the published Python package `okfile==1.2.3` and runs it through a thin Node wrapper, so users can start with `npx okfile ...` while keeping the existing Python CLI as the source of truth.

## Requirements

- Node.js `18+`
- Python `3.10+`
- internet access the first time the wrapper installs the Python package into the local cache

## Quick Start

Print the CLI version:

```bash
npx @okfilecom/okfile --version
```

Upload a file:

```bash
npx @okfilecom/okfile upload ./photo.jpg
```

Publish a static site directory:

```bash
npx @okfilecom/okfile publish ./my-site
```

Configure a saved API key:

```bash
npx @okfilecom/okfile config --key okf_xxxxx
```

## How It Works

- the npm package looks for a Python interpreter
- it installs `okfile==1.2.3` into a local cache directory under `~/.okfile/npm-python/1.2.3/`
- it forwards all CLI arguments to the Python entrypoint `okfile_cli.__main__:main`

## Environment

- `OKFILE_PYTHON`: optional explicit Python interpreter path or command

## Links

- Website: `https://www.okfile.com`
- PyPI: `https://pypi.org/project/okfile/`
- Repository: `https://github.com/okfilecom/okfile`
